#ifndef MY_UART_H
#define MY_UART_H

#include "usart.h"
#include "stdio.h"

void Check_Rx(void);
void Clean_receive(void);

#endif




