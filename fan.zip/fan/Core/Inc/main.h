/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define CSB_Echo_Pin GPIO_PIN_1
#define CSB_Echo_GPIO_Port GPIOC
#define CSB_Tring_Pin GPIO_PIN_2
#define CSB_Tring_GPIO_Port GPIOC
#define jiashikey_Pin GPIO_PIN_1
#define jiashikey_GPIO_Port GPIOA
#define speak6_Pin GPIO_PIN_1
#define speak6_GPIO_Port GPIOB
#define speak7_Pin GPIO_PIN_2
#define speak7_GPIO_Port GPIOB
#define speak2_Pin GPIO_PIN_12
#define speak2_GPIO_Port GPIOB
#define speak3_Pin GPIO_PIN_13
#define speak3_GPIO_Port GPIOB
#define speak4_Pin GPIO_PIN_14
#define speak4_GPIO_Port GPIOB
#define speak5_Pin GPIO_PIN_15
#define speak5_GPIO_Port GPIOB
#define key1_Pin GPIO_PIN_6
#define key1_GPIO_Port GPIOC
#define DHT11_Pin GPIO_PIN_9
#define DHT11_GPIO_Port GPIOA
#define speak1_Pin GPIO_PIN_12
#define speak1_GPIO_Port GPIOA
#define jiashiqi_Pin GPIO_PIN_10
#define jiashiqi_GPIO_Port GPIOC

/* USER CODE BEGIN Private defines */
#define DHT11_HIGH     HAL_GPIO_WritePin(GPIOA, DHT11_Pin,	GPIO_PIN_SET)
#define DHT11_LOW      HAL_GPIO_WritePin(GPIOA, DHT11_Pin, GPIO_PIN_RESET)
 
#define DHT11_IO_IN      HAL_GPIO_ReadPin(GPIOA, DHT11_Pin)
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
