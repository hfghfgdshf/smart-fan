/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "oled.h"
#include "DEV_Config.h"
#include "PAJ7620U2.h"
#include "My_UART.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

extern uint8_t RxBuffer[20];  
extern uint8_t RX_flag;
extern uint8_t Rx_len;


  uint8_t count=0;
  uint8_t temperature = 1 ; 
	uint8_t humidity = 1;
	uint8_t distance,distance_lock=1;//lock�жϾ���
	uint32_t pwmnum=0,pwmnum_flag;//pwmռ�ձȺ��ݴ�ֵ
	uint32_t speedflag;
  uint8_t  jiashiqi_flag=1;
  uint32_t duoji_angle=1500;
  
  
  unsigned char i;
	unsigned short  Gesture_Data;
//int fputc(int c,FILE *stream)
//{
//	HAL_UART_Transmit(&huart2,(unsigned char *)&c,1,0xffff);
//	return 1;
//}

//int fgetc(FILE *stream)
//{
//	int ch;
//	HAL_UART_Receive(&huart2,(uint8_t *)&ch,1,0xffff);
//	return ch;
//}
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
unsigned char PAJ7620U2_init()
{
	unsigned char i,State;
	DEV_Set_I2CAddress(PAJ7620U2_I2C_ADDRESS);
	DEV_Delay_ms(5);
	State = DEV_I2C_ReadByte(0x00);												//Read State
	if (State != 0x20) 
		return 0;																						//Wake up failed
	DEV_I2C_WriteByte(PAJ_BANK_SELECT, 0);								//Select Bank 0
	for (i=0;i< Init_Array;i++)
	{
		 DEV_I2C_WriteByte(Init_Register_Array[i][0], Init_Register_Array[i][1]);//Power up initialize
	}
	return 1;
}
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
void Delay_us(uint16_t delay);              
void DHT11_OUT(void);													
void DHT11_IN(void);                          
void DHT11_Strat(void);				                
uint8_t DHT11_Check(void);                   
uint8_t DHT11_Read_Bit(void);                 
uint8_t DHT11_Read_Byte(void);                
uint8_t DHT11_Read_Data(uint8_t* temp , uint8_t* humi);//��ʪ��

uint32_t csb_get_distance(void);//����

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void shoushi_task(void);//���ƴ�������
void display_task(void);//oled��ʾ��������
void lanya_task(void);//�����������ݴ���
void key_task(void);//��������
void duoji_task(void);//���
void speak_task(void);//��������
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  
  
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_I2C2_Init();
  MX_I2C3_Init();
  MX_USART2_UART_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */
  OLED_Init();
  OLED_Clear();
  HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_1);
	HAL_TIM_Base_Start_IT(&htim3);
    
    
	printf("Gesture Sensor Test Program ...\r\n");
	if(!PAJ7620U2_init())
	{	printf("\nGesture Sensor Error\r\n");
		return 0;
	}
		printf("\nGesture Sensor OK\r\n");
	DEV_I2C_WriteByte(PAJ_BANK_SELECT, 0);																	//Select Bank 0
	for (i = 0; i < Gesture_Array_SIZE; i++)
	{
		DEV_I2C_WriteByte(Init_Gesture_Array[i][0], Init_Gesture_Array[i][1]);//Gesture register initializes
	}
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    
    Check_Rx();   //�ж��Ƿ�������
    if(++count>=5)
    { 
      count=0;
      DHT11_Read_Data(&temperature , &humidity);//��ʪ��
      distance = csb_get_distance()/10;//����
		}
		display_task();
      
    shoushi_task();
    
    lanya_task();//�����������ݴ���
    
    key_task();
      
    speak_task();
    
    duoji_task();
    
    
    
			if(distance<=10&&distance_lock)
			{
        pwmnum_flag=pwmnum;
				pwmnum=0;
        distance_lock=0;
        
			}else if(distance>10&&distance_lock==0)//���������10ʱ�ָ�ԭ���ĵ���
      {
        distance_lock=1;
        pwmnum=pwmnum_flag;
        
      }
			
			if(pwmnum)
			{
				switch(pwmnum)
				{
					case	0:
						speedflag=0;
						break;
					case	4999:
						speedflag=1;
						break;
					case	9998:
						speedflag=2;
						break;
					case	14997:
						speedflag=3;
						break;
          case  19996:
            speedflag=4;
						break;
					default:
						break;
				}
			}
			if(pwmnum==0)
			{
				speedflag=0;
			}
			__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,pwmnum);
     
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV1;
  RCC_OscInitStruct.PLL.PLLN = 9;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
/*****************************��ʪ��ģ��&������ģ��***********************************************/
  void Delay_us(uint16_t delay)
  {
    __HAL_TIM_DISABLE(&htim3);
    __HAL_TIM_SET_COUNTER(&htim3,0);
    __HAL_TIM_ENABLE(&htim3);
    uint16_t curCnt=0;
    while(1)
    {
      curCnt=__HAL_TIM_GET_COUNTER(&htim3);
      if(curCnt>=delay)
        break;
    }
    __HAL_TIM_DISABLE(&htim3);
  }
   
  void TIM3_Delay_us(uint16_t n_us)
  {
    __HAL_TIM_SetCounter(&htim3, 0);
    __HAL_TIM_ENABLE(&htim3);
    
    while(__HAL_TIM_GetCounter(&htim3) < ((1 * n_us)-1));
    __HAL_TIM_DISABLE(&htim3);
  }

  void DHT11_OUT(void)
  {
    GPIO_InitTypeDef  GPIO_InitStruct = {0};
   
    GPIO_InitStruct.Pin = DHT11_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
  }
   
  void DHT11_IN(void)
  {
    GPIO_InitTypeDef  GPIO_InitStruct = {0};
   
    GPIO_InitStruct.Pin  = DHT11_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
  }
   
   
  void DHT11_Strat(void)
  {
    DHT11_OUT();
    DHT11_LOW;
    HAL_Delay(20);
    DHT11_HIGH;
    Delay_us(30);
  }
   
   
  uint8_t DHT11_Check(void)
  {
    uint8_t retry = 0 ;
    DHT11_IN();
      
    while(DHT11_IO_IN && retry <100) 
    {
      retry++;
      Delay_us(1);//1us
    }
    if(retry>=100) 
    {return  1;}
     else retry =  0 ;
      
    while(!DHT11_IO_IN && retry<100)
    {
      retry++;
      Delay_us(1);//1us
    }
      
    if(retry>=100)
    {return 1;}
    return 0 ;
  }
   
   
  uint8_t DHT11_Read_Bit(void)
  {
    uint8_t retry = 0 ;
    while(DHT11_IO_IN && retry <100)
    {
      retry++;
      Delay_us(1);
    }
      retry = 0 ;
    while(!DHT11_IO_IN && retry<100)
    {
      retry++;
      Delay_us(1);
    }
    Delay_us(40);
    if(DHT11_IO_IN) return 1;
    else 
    return 0 ;
  }
   
   
  uint8_t DHT11_Read_Byte(void)
  {
    uint8_t i , dat ;
    dat = 0 ;
    for(i=0; i<8; i++)
    {
      dat <<= 1;
      dat |= DHT11_Read_Bit();
    }
    return dat ; 
  }
   
   
  uint8_t DHT11_Read_Data(uint8_t* temp , uint8_t* humi)
  {
    uint8_t buf[5];
    uint8_t i;
    DHT11_Strat();
      if(DHT11_Check() == 0)
    {
      for(i=0; i<5; i++)
      {
        buf[i] = DHT11_Read_Byte();
      }
      if(buf[0]+buf[1]+buf[2]+buf[3] == buf[4])
      {
        *humi = buf[0];
        *temp = buf[2];
      }
    }else return 1;
    
     return 0 ;
  }
//��������ຯ��
 
  uint32_t csb_get_distance(void)
  {
    uint32_t CSB_value = 0;
    HAL_GPIO_WritePin(GPIOC,CSB_Tring_Pin,GPIO_PIN_SET);
    TIM3_Delay_us(20);
    HAL_GPIO_WritePin(GPIOC,CSB_Tring_Pin,GPIO_PIN_RESET);
    while(HAL_GPIO_ReadPin(CSB_Echo_GPIO_Port,CSB_Echo_Pin) == 0);
    __HAL_TIM_SetCounter(&htim3, 0);
    __HAL_TIM_ENABLE(&htim3);
    while(HAL_GPIO_ReadPin(CSB_Echo_GPIO_Port,CSB_Echo_Pin) == 1);
    CSB_value = __HAL_TIM_GetCounter(&htim3);
    __HAL_TIM_DISABLE(&htim3);
    return (CSB_value*340/1000/2);
  }
//���ƿ���
  
void shoushi_task()
{
  Gesture_Data = DEV_I2C_ReadWord(PAJ_INT_FLAG1);
		if (Gesture_Data)
		{
			switch (Gesture_Data)
			{
				case PAJ_UP:			  			 
					printf("��ת\r\n");	
					duoji_angle-=500;
        if(duoji_angle<=1000)
          duoji_angle=1000;
					break;
				case PAJ_DOWN:					
					printf("��ת\r\n");
          duoji_angle+=500;
        if(duoji_angle>=2000)
          duoji_angle=2000;
					break;
				case PAJ_LEFT:				
					printf("����\r\n");		
          pwmnum-=4999;	
					if(pwmnum>=60000)	
						pwmnum=0;//���
					break;
				case PAJ_RIGHT:				
					printf("�ӵ�\r\n"); 
           pwmnum+=4999;	
					if(pwmnum>=19999)	
						pwmnum=19996;
					break;
				case PAJ_FORWARD:		
//					printf("����\r\n");
//          __HAL_TIM_SET_COMPARE(&htim4,TIM_CHANNEL_1,1500);
					break;
				case PAJ_BACKWARD:			
					printf("Backward\r\n"); 			
					break;
				case PAJ_CLOCKWISE:				
					printf("Clockwise\r\n"); 				
					break;
				case PAJ_COUNT_CLOCKWISE:	
					printf("AntiClockwise\r\n"); 			
					break;
				case PAJ_WAVE:					
					printf("Wave\r\n"); 				
					break;
				default: break;
			}
			Gesture_Data=0;
			DEV_Delay_ms(50);
		}
}  
//oled��ʾ
void display_task()
{
      OLED_ShowCHinese(0,0,0);
			OLED_ShowCHinese(16,0,1);
			OLED_ShowCHinese(32,0,9);
			OLED_ShowNum(40,0,temperature,2,16);
			OLED_ShowCHinese(56,0,3);//�¶�
			
			OLED_ShowCHinese(0,2,2);
			OLED_ShowCHinese(16,2,1);
			OLED_ShowCHinese(32,2,9);
			OLED_ShowNum(40,2,humidity,2,16);
			OLED_ShowCHinese(56,2,8);//ʪ��
    
      OLED_ShowCHinese(0,4,6);
			OLED_ShowCHinese(16,4,7);
			OLED_ShowCHinese(32,4,9);
			OLED_ShowNum(40,4,distance,3,16);
      OLED_ShowString(64,4,"cm",16);   
      
      OLED_ShowCHinese(0,6,12);
			OLED_ShowCHinese(16,6,13);
			OLED_ShowCHinese(32,6,9);
      OLED_ShowNum(48,6,speedflag,1,16);//��λ
}
//��������
void lanya_task()
{
//  if(RxBuffer[0]==101)
//  {
//      pwmnum+=4999;
//        if(pwmnum>=19999)
//        {
//          pwmnum=19996;
//        }
//        printf("���ȼӵ�\r\n");
//        Clean_receive();//������ڽ��յ�����
//        
//  }
  
    if(RxBuffer[0]=='1'&&RxBuffer[1]=='0'&&RxBuffer[2]=='1')
    {
      pwmnum+=4999;
        if(pwmnum>=19999)
        {
          pwmnum=19996;
        }
        printf("���ȼӵ�\r\n");
        Clean_receive();//������ڽ��յ�����
    }
  
    if(RxBuffer[0]=='1'&&RxBuffer[1]=='0'&&RxBuffer[2]=='2')
    {
      pwmnum-=4999;
        if(pwmnum>=60000)
        {
          pwmnum=0;
        }
        printf("���ȼ���\r\n");
      Clean_receive();//������ڽ��յ�����
    }
    if(RxBuffer[0]=='1'&&RxBuffer[1]=='0'&&RxBuffer[2]=='3')
    {
      duoji_angle-=500;
        if(duoji_angle<=1000)
          duoji_angle=1000;
        printf("��ת\r\n");
      Clean_receive();//������ڽ��յ�����
    }
    
    if(RxBuffer[0]=='1'&&RxBuffer[1]=='0'&&RxBuffer[2]=='4')
    {
     duoji_angle+=500;
        if(duoji_angle>=2000)
          duoji_angle=2000;
        printf("��ת\r\n");
      Clean_receive();//������ڽ��յ�����
    }
    
    if(RxBuffer[0]=='1'&&RxBuffer[1]=='0'&&RxBuffer[2]=='5')
    {
          duoji_angle=1500;
        printf("�м�\r\n");
      Clean_receive();//������ڽ��յ�����
    }
    
    
    if(RxBuffer[0]=='1'&&RxBuffer[1]=='0'&&RxBuffer[2]=='6')
    {
      pwmnum=0;
      printf("�����ѹر�\r\n");
      Clean_receive();//������ڽ��յ�����
    }
    
    if(RxBuffer[0]=='1'&&RxBuffer[1]=='0'&&RxBuffer[2]=='7')//��ʪ��
    {
      jiashiqi_flag++;
      if(jiashiqi_flag%2==1)
        printf("��ʪ�ѿ���\r\n");
      else
        printf("��ʪ�ѹر�\r\n");
      HAL_GPIO_WritePin(jiashiqi_GPIO_Port,jiashiqi_Pin,(GPIO_PinState)(jiashiqi_flag%2));
      Clean_receive();//������ڽ��յ�����
    }
    
    if(RxBuffer[0]=='1'&&RxBuffer[1]=='0'&&RxBuffer[2]=='8')
    {
      printf("�¶ȣ�%d��\r\n",temperature);
      printf("ʪ�ȣ�%d%%\r\n",humidity);
      Clean_receive();//������ڽ��յ�����
    }
    
    if(RxBuffer[0]=='1'&&RxBuffer[1]=='0'&&RxBuffer[2]=='9')
    {
      printf("���٣�%d\r\n",speedflag);
      Clean_receive();//������ڽ��յ�����
    }
    
}
//��������
void key_task(void)
{
    if(HAL_GPIO_ReadPin(GPIOC,key1_Pin)==0)//��������&&������||HAL_GPIO_ReadPin(GPIOA,speak1_Pin)==1
			{
				pwmnum+=4999;
				while(HAL_GPIO_ReadPin(GPIOC,key1_Pin)==0)//||HAL_GPIO_ReadPin(GPIOA,speak1_Pin)==1
				{
					__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,pwmnum);
				}
        if(pwmnum>=19999)
        {
          pwmnum=0;
        }
			}
    if(HAL_GPIO_ReadPin(jiashikey_GPIO_Port,jiashikey_Pin)==0)
    {
      while(HAL_GPIO_ReadPin(jiashikey_GPIO_Port,jiashikey_Pin)==0);
      jiashiqi_flag++;
      HAL_GPIO_WritePin(jiashiqi_GPIO_Port,jiashiqi_Pin,(GPIO_PinState)(jiashiqi_flag%2));
    }
    
}
//���
void duoji_task(void)
{
   __HAL_TIM_SET_COMPARE(&htim4,TIM_CHANNEL_1,duoji_angle);
}
//speak
void speak_task(void)
{
      if(HAL_GPIO_ReadPin(speak1_GPIO_Port,speak1_Pin)==1)//�ӵ�
			{
				pwmnum+=4999;
//				while(HAL_GPIO_ReadPin(speak1_GPIO_Port,speak1_Pin)==1)
//				{
//					__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,pwmnum);
//				}
					if(pwmnum>=20000)
					{
						pwmnum=19996;
					}
			}
      if(HAL_GPIO_ReadPin(speak2_GPIO_Port,speak2_Pin)==1)//
			{
				pwmnum-=4999;
//				while(HAL_GPIO_ReadPin(GPIOA,speak2_Pin)==1)
//				{
//					__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,pwmnum);
//				}
					if(pwmnum>=60000)
					{
						pwmnum=0;
					}
			}
      if(HAL_GPIO_ReadPin(speak3_GPIO_Port,speak3_Pin)==1)//��ת
      {
        duoji_angle-=500;
        if(duoji_angle<=1000)
          duoji_angle=1000;
      }
      if(HAL_GPIO_ReadPin(speak4_GPIO_Port,speak4_Pin)==1)//��ת
      {
        duoji_angle+=500;
        if(duoji_angle>=2000)
          duoji_angle=2000;
      }
      if(HAL_GPIO_ReadPin(speak5_GPIO_Port,speak5_Pin)==1)//�رշ���
      {
        pwmnum=0;
      }

      if(HAL_GPIO_ReadPin(speak6_GPIO_Port,speak6_Pin)==1)//�򿪼�ʪ��
      {
        jiashiqi_flag++;
      HAL_GPIO_WritePin(jiashiqi_GPIO_Port,jiashiqi_Pin,(GPIO_PinState)(jiashiqi_flag%2));
      }
      if(HAL_GPIO_ReadPin(speak7_GPIO_Port,speak7_Pin)==1)//�رռ�ʪ��
      {
        jiashiqi_flag++;
      HAL_GPIO_WritePin(jiashiqi_GPIO_Port,jiashiqi_Pin,(GPIO_PinState)(jiashiqi_flag%2));
      }
      
}
/*************************************************************************************************/
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
